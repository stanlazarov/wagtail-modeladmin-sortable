from django import forms


class SortingForm(forms.Form):
    pass
